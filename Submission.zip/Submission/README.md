# Dicoding Collection Dashboard ✨

## Setup environment
```
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel
```

## Run steamlit app
```
streamlit run dashboard/dashboard.py
```

